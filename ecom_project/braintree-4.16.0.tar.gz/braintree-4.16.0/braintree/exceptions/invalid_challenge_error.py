from braintree.exceptions.braintree_error import BraintreeError

class InvalidChallengeError(BraintreeError):
    pass
