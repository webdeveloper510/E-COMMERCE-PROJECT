from braintree.attribute_getter import AttributeGetter

class DisputeStatusHistory(AttributeGetter):
    def __init__(self, attributes):
        AttributeGetter.__init__(self, attributes)
