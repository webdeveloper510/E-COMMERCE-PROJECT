from braintree.attribute_getter import AttributeGetter

class FacilitatedDetails(AttributeGetter):
    pass
