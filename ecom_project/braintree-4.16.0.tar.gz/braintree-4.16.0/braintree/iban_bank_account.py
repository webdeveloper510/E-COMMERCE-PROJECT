from braintree.resource import Resource

class IbanBankAccount(Resource):
    pass
