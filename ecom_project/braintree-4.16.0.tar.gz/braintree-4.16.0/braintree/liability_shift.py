from braintree.attribute_getter import AttributeGetter

class LiabilityShift(AttributeGetter):
    pass
