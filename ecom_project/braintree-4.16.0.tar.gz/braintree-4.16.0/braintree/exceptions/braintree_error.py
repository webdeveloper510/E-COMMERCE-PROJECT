class BraintreeError(Exception):
    pass
