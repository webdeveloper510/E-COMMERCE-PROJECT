from braintree.attribute_getter import AttributeGetter

class ApplePayOptions(AttributeGetter):
    pass
